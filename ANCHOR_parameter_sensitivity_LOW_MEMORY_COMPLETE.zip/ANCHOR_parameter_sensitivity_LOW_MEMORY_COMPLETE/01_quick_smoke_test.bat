@echo off
python run_anchor_sensitivity_analysis.py --panel quick --setting default,start_penalty_0
pause
