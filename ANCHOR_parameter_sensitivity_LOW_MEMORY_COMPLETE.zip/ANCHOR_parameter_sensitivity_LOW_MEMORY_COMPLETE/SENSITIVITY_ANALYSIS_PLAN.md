# Reviewer sensitivity-analysis plan

## Reviewer concern

Several parameter bounds, penalties, and model-selection thresholds may influence the selected kinetic phases. The sensitivity analysis therefore changes one setting at a time while all other ANCHOR settings and all synthetic traces remain fixed.

## Primary panel

The recommended `balanced` panel contains 75 traces:

- direct, moderate-rate regime: low / medium / high noise
- one-intermediate, moderate-rate regime: low / medium / high noise
- two-intermediate, moderate-rate regime: low / medium / high noise
- linear, moderate-slope regime: low / medium / high noise
- no-binding, mid-signal regime: low / medium / high noise

Each case contains five independently noise-seeded traces.

This panel is deliberately balanced across the five truth classes and all three noise levels while keeping the computational burden manageable. A `full` option is included to repeat the analysis on all 225 primary model-selection traces.

## One-at-a-time perturbations

No-binding/model-selection guardrail:
- BIC preference tolerance: 2, 6 (default), 10
- noise multiplier: 1.5, 2.0 (default), 3.0
- minimum signal change: 0.025, 0.05 (default), 0.10
- within-noise automatic no-binding preference: on (default) vs off

Shape penalties:
- start-value penalty weight: 0, 4 (default), 8
- early-peak penalty weight: 0, 100 (default), 200

Rate/response bounds:
- standard k1 upper bound: 1e4, 1e6 (default), 1e8 mM^-1 min^-1
- subsequent first-order-rate upper bound: 1e2, 1e4 (default), 1e6 min^-1
- positive rate floor: 1e-10, 1e-8 (default), 1e-6
- response-coefficient upper bound: 1.5, 3.0 (default), 6.0
- first-intermediate response cap: on (default) vs off

## Primary endpoints

For each perturbation report:
1. percentage of traces whose selected model is unchanged from the default;
2. percentage of kinetic traces whose selected phase count is unchanged;
3. known-truth model recovery rate;
4. truth-class/noise-stratified recovery;
5. the identities of traces that change selection.

The reviewer-facing claim should be based primarily on selection stability, not only truth accuracy. A setting can preserve the same interpretation even when the generating mechanism is not fully identifiable from the trace.

## What the sensitivity analysis does NOT test

Savitzky-Golay smoothing is kept separate because Reviewer 2 specifically requested a dedicated analysis of smoothing strength. Reversible-MM microscopic identifiability is also treated separately using the individual-versus-global turnover benchmark.
