#!/usr/bin/env bash
set -e
cd "/home/scs/kihn/ANCHOR/ANCHOR_parameter_sensitivity_LOW_MEMORY"
echo "Working directory: $(pwd)"
python run_anchor_sensitivity_low_memory.py "$@"
