#!/usr/bin/env bash
set -e
cd "/home/scs/kihn/ANCHOR/ANCHOR_parameter_sensitivity_LOW_MEMORY"
python run_anchor_sensitivity_low_memory.py --panel balanced --replicates 1 --setting default,bic_tolerance_2,bic_tolerance_10
