@echo off
python run_anchor_sensitivity_analysis.py --panel full
pause
