#!/usr/bin/env python
"""
Process-isolated ANCHOR sensitivity analysis.

Why this runner exists
----------------------
The original sensitivity driver kept importing/running ANCHOR repeatedly in one
long-lived Python process. On memory-constrained Linux systems, accumulated
scientific-library state and repeated optimization/plot-generation can cause
very high memory pressure. A Linux "Killed" message is commonly the result of
the kernel or scheduler terminating a process under resource pressure.

This version runs ONE case under ONE sensitivity setting in a fresh child
Python process. When that case finishes, the entire worker exits and the OS
reclaims its memory before the next case begins.

It also limits BLAS/OpenMP thread pools to one thread and, by default, uses two
of the five synthetic replicates per condition for the reviewer sensitivity
panel. The original five-replicate inputs remain untouched.

Recommended:
    python run_anchor_sensitivity_low_memory.py --panel balanced --profile primary --replicates 2

Very conservative first run:
    python run_anchor_sensitivity_low_memory.py --panel balanced --profile primary --replicates 1 --setting default,bic_tolerance_2,bic_tolerance_10

Full five-replicate analysis, only if resources allow:
    python run_anchor_sensitivity_low_memory.py --panel balanced --profile primary --replicates 5
"""

from __future__ import annotations

# These MUST be set before NumPy/SciPy are imported.
import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")
os.environ.setdefault("MPLBACKEND", "Agg")

import argparse
import importlib.util
import json
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd

SCRIPT_DIR = Path(__file__).resolve().parent
REQUESTED_ROOT = Path(r"/home/scs/kihn/ANCHOR/ANCHOR_parameter_sensitivity_LOW_MEMORY")

# Use the requested installation path when it exists. If the folder is moved,
# fall back to the directory containing this script.
HERE = REQUESTED_ROOT if REQUESTED_ROOT.exists() else SCRIPT_DIR
DEFAULT_ANCHOR = HERE / "ANCHOR.py"
DEFAULT_PACKAGE = HERE / "ANCHOR_reviewer_simulated_validation"
DEFAULT_OUT = HERE / "ANCHOR_sensitivity_outputs_low_memory"

BALANCED_CASES = [
    "MS004", "MS005", "MS006",  # direct, moderate: low/medium/high
    "MS013", "MS014", "MS015",  # 1 intermediate, moderate
    "MS022", "MS023", "MS024",  # 2 intermediates, moderate
    "MS031", "MS032", "MS033",  # linear, moderate
    "MS040", "MS041", "MS042",  # no binding, mid signal
]
QUICK_CASES = ["MS004", "MS013", "MS022", "MS031", "MS040"]

SETTINGS: Dict[str, Dict[str, Any]] = {
    "default": {},
    "bic_tolerance_2": {"no_binding_bic_preference_tolerance": 2.0},
    "bic_tolerance_10": {"no_binding_bic_preference_tolerance": 10.0},
    "noise_multiplier_1p5": {"no_binding_noise_multiplier": 1.5},
    "noise_multiplier_3": {"no_binding_noise_multiplier": 3.0},
    "min_signal_change_0p025": {"no_binding_min_signal_change": 0.025},
    "min_signal_change_0p10": {"no_binding_min_signal_change": 0.10},
    "start_penalty_0": {"start_value_penalty_weight": 0.0},
    "start_penalty_8": {"start_value_penalty_weight": 8.0},
    "peak_penalty_0": {"initial_peak_penalty_weight": 0.0},
    "peak_penalty_200": {"initial_peak_penalty_weight": 200.0},
    "k1_upper_1e4": {"standard_k1_max": 1e4},
    "k1_upper_1e8": {"standard_k1_max": 1e8},
    "later_rate_upper_1e2": {"k_other_max": 1e2},
    "later_rate_upper_1e6": {"k_other_max": 1e6},
    # Extended-only settings:
    "noise_guardrail_off": {"no_binding_prefer_if_change_within_noise": False},
    "rate_floor_1e10": {
        "standard_k1_min": 1e-10,
        "slow_apo_k1_min": 1e-10,
        "k_other_min": 1e-10,
    },
    "rate_floor_1e6": {
        "standard_k1_min": 1e-6,
        "slow_apo_k1_min": 1e-6,
        "k_other_min": 1e-6,
    },
    "response_upper_1p5": {"response_max": 1.5},
    "response_upper_6": {"response_max": 6.0},
    "first_intermediate_cap_off": {"first_intermediate_must_not_exceed_E": False},
}

PRIMARY_SETTINGS = [
    "default",
    "bic_tolerance_2", "bic_tolerance_10",
    "noise_multiplier_1p5", "noise_multiplier_3",
    "min_signal_change_0p025", "min_signal_change_0p10",
    "start_penalty_0", "start_penalty_8",
    "peak_penalty_0", "peak_penalty_200",
    "k1_upper_1e4", "k1_upper_1e8",
    "later_rate_upper_1e2", "later_rate_upper_1e6",
]
EXTENDED_SETTINGS = list(SETTINGS.keys())


def load_anchor(anchor_path: Path):
    spec = importlib.util.spec_from_file_location("anchor_sensitivity_worker", anchor_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load ANCHOR module: {anchor_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(spec.name, None)
        raise
    return module


def truth_label_from_anchor_row(row: pd.Series) -> str:
    model_type = str(row.get("model_type", ""))
    if model_type == "linear_only":
        return "linear"
    if model_type == "no_binding":
        return "no_binding"
    if model_type == "reversible_mm":
        return "reversible_mm"
    if model_type == "kinetic":
        try:
            n = int(float(row.get("best_n_intermediates", -99)))
        except Exception:
            return "kinetic_unknown"
        if n == 0:
            return "direct"
        if n == 1:
            return "one_intermediate"
        if n == 2:
            return "two_intermediate"
        return f"{n}_intermediates"
    return model_type or "unknown"


def phase_count(label: str):
    if label == "direct":
        return 0
    if label == "one_intermediate":
        return 1
    if label == "two_intermediate":
        return 2
    if label.endswith("_intermediates"):
        try:
            return int(label.split("_")[0])
        except Exception:
            return None
    return None


def make_replicate_subset(original_csv: Path, subset_csv: Path, n_replicates: int) -> None:
    df = pd.read_csv(original_csv)
    if df.shape[1] < n_replicates + 1:
        raise ValueError(
            f"{original_csv.name} contains only {df.shape[1]-1} traces; "
            f"cannot select {n_replicates}."
        )
    subset_csv.parent.mkdir(parents=True, exist_ok=True)
    df.iloc[:, : n_replicates + 1].to_csv(subset_csv, index=False)


def configure_case(mod, input_csv: Path, out_parent: Path, folder_name: str,
                   n_replicates: int, overrides: Dict[str, Any]):
    cfg = mod.FittingConfig()
    cfg.input_csv = str(input_csv)
    cfg.output_parent = str(out_parent)
    cfg.output_folder_name = folder_name

    cfg.input_time_unit = "minutes"
    cfg.enzyme_concentration_unit = "µM"
    cfg.substrate_concentration_unit = "µM"
    cfg.E0_uM = 5.0
    cfg.concentration_groups = [mod.ConcentrationGroup(200.0, n_replicates)]
    cfg.analysis_mode = "general_auto"
    cfg.max_intermediates = 5
    cfg.include_zero_intermediate_kinetic_model = True
    cfg.use_standard_fit_mode = True
    cfg.use_slow_apo_fit_mode = True
    cfg.include_linear_only_model = True
    cfg.include_no_binding_model = True
    cfg.include_reversible_mm_model = False
    cfg.fit_michaelis_menten = False

    for key, value in overrides.items():
        if not hasattr(cfg, key):
            raise AttributeError(f"FittingConfig has no setting {key!r}")
        setattr(cfg, key, value)
    return cfg


def prune_heavy_outputs(case_dir: Path):
    """Keep auditable tables/config, delete generated images/workbooks."""
    for p in case_dir.rglob("*"):
        if p.is_file() and p.suffix.lower() in {".png", ".tif", ".tiff", ".xlsx"}:
            try:
                p.unlink()
            except OSError:
                pass


def worker_main(args) -> int:
    anchor_path = Path(args.anchor).resolve()
    package = Path(args.package).resolve()
    out_root = Path(args.out).resolve()
    manifest = pd.read_csv(package / "simulation_manifest.csv")
    row = manifest[manifest["case_id"].astype(str) == args.worker_case]
    if row.empty:
        raise ValueError(f"Unknown case: {args.worker_case}")
    m = row.iloc[0]

    setting = args.worker_setting
    overrides = SETTINGS[setting]
    setting_out = out_root / setting
    case_dir = setting_out / args.worker_case
    compact_path = case_dir / "sensitivity_compact.csv"

    if compact_path.exists() and not args.force:
        return 0

    if args.force and case_dir.exists():
        shutil.rmtree(case_dir)

    subset_csv = out_root / "_input_subsets" / f"{args.worker_case}_rep{args.replicates}.csv"
    if not subset_csv.exists():
        make_replicate_subset(
            package / str(m["file"]),
            subset_csv,
            args.replicates,
        )

    mod = load_anchor(anchor_path)
    cfg = configure_case(
        mod, subset_csv, setting_out, args.worker_case, args.replicates, overrides
    )
    mod.StoppedFlowFitter(cfg).run()

    best_path = case_dir / "best_fit_summary.csv"
    if not best_path.exists():
        raise FileNotFoundError(best_path)

    best = pd.read_csv(best_path)
    rows: List[Dict[str, Any]] = []
    for trace_index, (_, r) in enumerate(best.iterrows(), start=1):
        selected = truth_label_from_anchor_row(r)
        rec = {
            "setting": setting,
            "case_id": args.worker_case,
            "trace_index": trace_index,
            "truth_model": str(m["truth_model"]),
            "truth_regime": str(m["truth_regime"]),
            "noise_level": str(m["noise_level"]),
            "selected_model": selected,
            "selected_phase_count": phase_count(selected),
            "truth_phase_count": phase_count(str(m["truth_model"])),
            "correct_model": selected == str(m["truth_model"]),
        }
        for col in [
            "model_type", "fit_mode", "best_n_intermediates", "RSS", "AIC",
            "BIC", "n_params", "selection_reason",
            "no_binding_noise_sigma", "no_binding_signal_change_threshold",
            "best_nonconstant_signal_change",
        ]:
            if col in r.index:
                rec[col] = r[col]
        rows.append(rec)

    pd.DataFrame(rows).to_csv(compact_path, index=False)
    if not args.keep_case_outputs:
        prune_heavy_outputs(case_dir)
    return 0


def aggregate(out_root: Path):
    compact_files = sorted(out_root.glob("*/*/sensitivity_compact.csv"))
    if not compact_files:
        raise RuntimeError("No completed sensitivity cases were found.")
    results = pd.concat([pd.read_csv(p) for p in compact_files], ignore_index=True)
    results.to_csv(out_root / "ANCHOR_sensitivity_all_results.csv", index=False)

    default = results[results["setting"] == "default"][
        ["case_id", "trace_index", "selected_model", "selected_phase_count", "correct_model"]
    ].rename(columns={
        "selected_model": "default_selected_model",
        "selected_phase_count": "default_selected_phase_count",
        "correct_model": "default_correct_model",
    })

    comp = results.merge(default, on=["case_id", "trace_index"], how="left")
    comp["selection_unchanged_from_default"] = (
        comp["selected_model"].astype(str) == comp["default_selected_model"].astype(str)
    )

    kinetic_mask = comp["truth_model"].isin(["direct", "one_intermediate", "two_intermediate"])
    comp["phase_count_unchanged_from_default"] = False
    comp.loc[kinetic_mask, "phase_count_unchanged_from_default"] = (
        comp.loc[kinetic_mask, "selected_phase_count"].fillna(-99)
        == comp.loc[kinetic_mask, "default_selected_phase_count"].fillna(-99)
    )
    comp.to_csv(out_root / "ANCHOR_sensitivity_trace_level_comparison.csv", index=False)

    summary_rows = []
    for setting_name, group in comp.groupby("setting", sort=False):
        kinetic = group[group["truth_model"].isin(["direct", "one_intermediate", "two_intermediate"])]
        summary_rows.append({
            "setting": setting_name,
            "n_traces": len(group),
            "selection_stability_vs_default": float(group["selection_unchanged_from_default"].mean()),
            "truth_accuracy": float(group["correct_model"].mean()),
            "n_kinetic_traces": len(kinetic),
            "kinetic_phase_count_stability_vs_default": (
                float(kinetic["phase_count_unchanged_from_default"].mean()) if len(kinetic) else float("nan")
            ),
            "kinetic_truth_accuracy": float(kinetic["correct_model"].mean()) if len(kinetic) else float("nan"),
            "n_changed_selections": int((~group["selection_unchanged_from_default"]).sum()),
        })

    pd.DataFrame(summary_rows).to_csv(out_root / "ANCHOR_sensitivity_summary.csv", index=False)

    by_truth_noise = (
        comp.groupby(["setting", "truth_model", "noise_level"], as_index=False)
        .agg(
            n=("correct_model", "size"),
            truth_accuracy=("correct_model", "mean"),
            selection_stability_vs_default=("selection_unchanged_from_default", "mean"),
        )
    )
    by_truth_noise.to_csv(out_root / "ANCHOR_sensitivity_by_truth_and_noise.csv", index=False)

    changed = comp[
        (comp["setting"] != "default")
        & (~comp["selection_unchanged_from_default"])
    ].copy()
    changed.to_csv(out_root / "ANCHOR_sensitivity_changed_traces.csv", index=False)


def controller_main(args) -> int:
    package = Path(args.package).resolve()
    out_root = Path(args.out).resolve()
    out_root.mkdir(parents=True, exist_ok=True)

    manifest = pd.read_csv(package / "simulation_manifest.csv")
    manifest = manifest[manifest["suite"].astype(str) == "model_selection"].copy()

    if args.panel == "quick":
        case_ids = QUICK_CASES
    elif args.panel == "balanced":
        case_ids = BALANCED_CASES
    else:
        case_ids = manifest["case_id"].astype(str).tolist()

    if args.setting:
        requested = [s.strip() for s in args.setting.split(",") if s.strip()]
        unknown = [s for s in requested if s not in SETTINGS]
        if unknown:
            raise ValueError(f"Unknown settings: {unknown}")
        settings = ["default"] + [s for s in requested if s != "default"]
    elif args.profile == "primary":
        settings = PRIMARY_SETTINGS
    else:
        settings = EXTENDED_SETTINGS

    total = len(settings) * len(case_ids)
    print("Low-memory sensitivity analysis")
    print(f"Panel: {args.panel}")
    print(f"Replicates per condition: {args.replicates}")
    print(f"Settings: {len(settings)}")
    print(f"Case jobs: {total}")
    print("Each case job runs in a fresh process; jobs are strictly sequential.")
    print()

    failures = []
    job_no = 0
    for setting in settings:
        for case_id in case_ids:
            job_no += 1
            compact = out_root / setting / case_id / "sensitivity_compact.csv"
            if compact.exists() and not args.force:
                print(f"[{job_no}/{total}] reuse {setting}/{case_id}")
                continue

            print(f"[{job_no}/{total}] run   {setting}/{case_id}")
            log_dir = out_root / "_logs" / setting
            log_dir.mkdir(parents=True, exist_ok=True)
            log_path = log_dir / f"{case_id}.log"

            cmd = [
                sys.executable,
                str(Path(__file__).resolve()),
                "--worker",
                "--worker-setting", setting,
                "--worker-case", case_id,
                "--replicates", str(args.replicates),
                "--anchor", str(Path(args.anchor).resolve()),
                "--package", str(package),
                "--out", str(out_root),
            ]
            if args.force:
                cmd.append("--force")
            if args.keep_case_outputs:
                cmd.append("--keep-case-outputs")

            env = os.environ.copy()
            env.update({
                "OMP_NUM_THREADS": "1",
                "OPENBLAS_NUM_THREADS": "1",
                "MKL_NUM_THREADS": "1",
                "NUMEXPR_NUM_THREADS": "1",
                "VECLIB_MAXIMUM_THREADS": "1",
                "MPLBACKEND": "Agg",
            })

            with open(log_path, "w", encoding="utf-8") as log:
                result = subprocess.run(
                    cmd,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    env=env,
                    cwd=HERE,
                )

            if result.returncode != 0:
                failures.append({
                    "setting": setting,
                    "case_id": case_id,
                    "returncode": result.returncode,
                    "log": str(log_path),
                })
                print(f"    FAILED (return code {result.returncode}); see {log_path}")
                if args.stop_on_failure:
                    break
            else:
                print("    completed; worker memory released")
        if failures and args.stop_on_failure:
            break

        # Aggregate after each setting so progress is preserved.
        try:
            aggregate(out_root)
        except Exception:
            pass

    if failures:
        pd.DataFrame(failures).to_csv(out_root / "ANCHOR_sensitivity_failures.csv", index=False)

    aggregate(out_root)
    print()
    print("Finished.")
    print("Primary files:")
    print(out_root / "ANCHOR_sensitivity_summary.csv")
    print(out_root / "ANCHOR_sensitivity_by_truth_and_noise.csv")
    print(out_root / "ANCHOR_sensitivity_changed_traces.csv")
    if failures:
        print(f"Failures: {len(failures)} (see ANCHOR_sensitivity_failures.csv)")
    return 0


def build_parser():
    p = argparse.ArgumentParser()
    p.add_argument("--anchor", default=str(DEFAULT_ANCHOR))
    p.add_argument("--package", default=str(DEFAULT_PACKAGE))
    p.add_argument("--out", default=str(DEFAULT_OUT))
    p.add_argument("--panel", choices=["quick", "balanced", "full"], default="balanced")
    p.add_argument("--profile", choices=["primary", "extended"], default="primary")
    p.add_argument("--setting", default=None, help="Comma-separated explicit setting names.")
    p.add_argument("--replicates", type=int, choices=[1, 2, 3, 4, 5], default=2)
    p.add_argument("--force", action="store_true")
    p.add_argument("--keep-case-outputs", action="store_true")
    p.add_argument("--stop-on-failure", action="store_true")

    # Internal worker mode
    p.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    p.add_argument("--worker-setting", default=None, help=argparse.SUPPRESS)
    p.add_argument("--worker-case", default=None, help=argparse.SUPPRESS)
    return p


if __name__ == "__main__":
    args = build_parser().parse_args()
    if args.worker:
        raise SystemExit(worker_main(args))
    raise SystemExit(controller_main(args))
