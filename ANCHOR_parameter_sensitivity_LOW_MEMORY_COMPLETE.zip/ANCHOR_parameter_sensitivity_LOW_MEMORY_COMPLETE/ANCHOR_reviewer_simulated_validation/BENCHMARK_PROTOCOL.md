# Reviewer-validation protocol

## 1. Primary question

The synthetic benchmark should answer two distinct questions:

1. **Model recovery:** when the data-generating model is known, how often does each
   program identify the correct model class?
2. **Parameter recovery:** when the correct model is fitted, how close are fitted
   kinetic parameters to the known simulated values?

Do not frame the comparison as a contest in which ANCHOR is expected to numerically
outperform DYNAFIT. DYNAFIT is a flexible mechanism-driven fitting package. The
intended ANCHOR advantage is automated trace-level candidate comparison, consistent
treatment of heterogeneous traces, empirical linear/no-binding controls, and an
auditable GUI/output workflow.

## 2. ANCHOR analysis

### Model-selection suite
For every CSV in `model_selection/`:
- E0 = 5 uM
- one concentration group: 200 uM, 5 samples
- analysis mode: General automatic
- use the manuscript/default fitting settings
- allow direct, 1-5-intermediate, linear, and no-binding candidates
- record selected model, selected number of intermediates, BIC, fitted parameters,
  fit success, and runtime.

### Turnover suite
For every CSV in `turnover/`:
- E0 = 40 uM
- groups: 360x3, 675x3, 1350x3, 2250x3, 3150x3, 4500x3 uM
- analysis mode: Automatic turnover mechanism detection
- record direct versus reversible-MM selection, fitted microscopic parameters,
  Km, Vmax, velocities, fit success, and runtime.

## 3. DYNAFIT comparison

For a fair model-selection comparison, do not give DYNAFIT the true generating
mechanism in advance. Fit the same candidate kinetic mechanisms separately, then
rank them using the same BIC definition used for ANCHOR:

BIC = n ln(RSS/n) + p ln(n)

where RSS is calculated from the raw-data residuals, n is the number of observations,
and p is the number of fitted parameters.

For direct, one-intermediate, two-intermediate, and reversible-MM truth cases, compare:
- correct-model rate
- parameter relative error
- raw-data RMSE
- fitting failure rate
- runtime

Linear and no-binding cases can be retained as an ANCHOR-specific diagnostic benchmark.
If DYNAFIT is also used for them, define equivalent constant and linear candidate
models prospectively and apply the same BIC calculation.

## 4. Recommended primary figures/tables

Main manuscript:
- confusion matrix or stacked accuracy plot for model recovery versus noise level
- table comparing ANCHOR and DYNAFIT correct-model rate and parameter error

Supplement:
- truth parameters for every simulated case
- full per-trace results
- representative fit overlays at low, medium, and high noise
- sensitivity-analysis table

## 5. Sensitivity analysis

Use one-at-a-time perturbations around the ANCHOR defaults rather than an enormous
full-factorial grid. Suggested settings:

- smoothing target:
  - OFF
  - 5% window / polynomial 2
  - 10% window / polynomial 3 (default)
  - 20% window / polynomial 3
- smoothed-target weight: 0.75, 1.5 (default), 3.0
- no-binding BIC tolerance: 2, 6 (default), 10
- no-binding noise multiplier: 1.5, 2.0 (default), 3.0
- no-binding minimum signal change: 0.025, 0.05 (default), 0.10
- start-value penalty: 0, 2, 4 (default), 8
- early-peak penalty weight: 0, 50, 100 (default), 200
- multistart effort:
  - 6 screen / 12 refine
  - 12 / 25 (default)
  - 24 / 50
- rate upper bounds:
  - k1 max: 1e4, 1e6 (default), 1e8
  - later rates max: 1e2, 1e4 (default), 1e6

Report:
- percent of traces retaining the same selected model as the default analysis
- percent of synthetic traces recovering the true model
- median absolute relative error for identifiable kinetic parameters

## 6. Savitzky-Golay analysis

The manuscript should explicitly state that smoothing is an auxiliary optimization
target. Final AIC/BIC values should continue to be calculated from residuals to the
raw observations, not from the smoothed trace. Demonstrate this by repeating the
synthetic benchmark with smoothing off and with the window/weight variations above.

## 7. Integrated Michaelis-Menten / Lambert-W check

Add a separate validation of simple Michaelis-Menten progress curves using the
Schnell-Mendoza integrated solution:

S(t) = Km * W[(S0/Km) * exp((S0 - Vmax*t)/Km)]
P(t) = S0 - S(t)

Fit the six SPpNA progress curves globally with shared Vmax and Km (allowing only
trace-specific offsets if required). Compare these estimates with:
- ANCHOR's existing velocity-based Michaelis-Menten fit
- the GraphPad fit of manual velocities

This directly answers the reviewer while making clear that the Lambert-W equation
applies to the integrated Michaelis-Menten rate law, whereas ANCHOR's reversible
E+S <-> ES -> E+P candidate is a full mass-action ODE model.

## 8. Suggested success criteria

The clean/low-noise benchmark should show near-complete recovery of clearly
distinguishable models. Accuracy is expected to decrease at high noise and for weak
linear/no-binding boundary cases; those failures should be reported rather than
hidden. The important result is to characterize where ANCHOR is reliable and where
model order becomes practically non-identifiable.
