from pathlib import Path
import numpy as np
import csv, json
from scipy.integrate import solve_ivp

OUT = Path("simulated_validation")
(OUT / "model_selection").mkdir(parents=True, exist_ok=True)
(OUT / "turnover").mkdir(parents=True, exist_ok=True)

BASE_SEED = 20261013
NOISE = {"low": 0.005, "medium": 0.020, "high": 0.050}

def seq_signal(time, S_mM, rates, responses):
    rates = np.asarray(rates, float)
    n_species = len(rates) + 1
    y0 = np.zeros(n_species)
    y0[0] = 1.0

    def ode(t, y):
        dy = np.zeros_like(y)
        flux = rates[0] * S_mM * y[0]
        dy[0] -= flux
        dy[1] += flux
        for i in range(1, n_species - 1):
            flux = rates[i] * y[i]
            dy[i] -= flux
            dy[i + 1] += flux
        return dy

    sol = solve_ivp(
        ode, (float(time[0]), float(time[-1])), y0,
        t_eval=time, method="DOP853", rtol=1e-10, atol=1e-12
    )
    if not sol.success:
        raise RuntimeError(sol.message)
    return np.asarray(responses, float) @ sol.y

def reversible_mm_signal(time, S0_mM, kon, koff, kcat,
                         E0_mM=0.040, response_E=1.0,
                         response_ES=0.2, response_P=8.0):
    def ode(t, y):
        E, S, ES, P = y
        a = kon * E * S
        d = koff * ES
        c = kcat * ES
        return [-a + d + c, -a + d, a - d - c, c]

    sol = solve_ivp(
        ode, (float(time[0]), float(time[-1])),
        [E0_mM, S0_mM, 0.0, 0.0],
        t_eval=time, method="DOP853", rtol=1e-10, atol=1e-12
    )
    if not sol.success:
        raise RuntimeError(sol.message)

    E, S, ES, P = sol.y
    return (
        response_E * E / E0_mM
        + response_ES * ES / E0_mM
        + response_P * P / S0_mM
    )

manifest = []
trace_template = []

# -------------------- model-selection suite --------------------
time = np.round(np.linspace(0.0, 2.0, 201), 6)
S_uM = 200.0
S_mM = S_uM / 1000.0

cases = {
    "direct": {
        "slow": {"rates": [2.5], "responses": [1.0, 0.25]},
        "moderate": {"rates": [10.0], "responses": [1.0, 0.25]},
        "fast": {"rates": [30.0], "responses": [1.0, 0.25]},
    },
    "one_intermediate": {
        "slow": {"rates": [2.5, 0.8], "responses": [1.0, 0.12, 0.70]},
        "moderate": {"rates": [10.0, 2.5], "responses": [1.0, 0.12, 0.70]},
        "fast": {"rates": [30.0, 6.0], "responses": [1.0, 0.12, 0.70]},
    },
    "two_intermediate": {
        "slow": {"rates": [3.0, 1.2, 0.5], "responses": [1.0, 0.10, 0.50, 1.05]},
        "moderate": {"rates": [12.0, 3.0, 1.0], "responses": [1.0, 0.10, 0.50, 1.05]},
        "fast": {"rates": [30.0, 8.0, 2.5], "responses": [1.0, 0.10, 0.50, 1.05]},
    },
    "linear": {
        "weak": {"intercept": 0.80, "slope": -0.04},
        "moderate": {"intercept": 0.80, "slope": -0.12},
        "strong": {"intercept": 0.80, "slope": -0.25},
    },
    "no_binding": {
        "low_signal": {"intercept": 0.50},
        "mid_signal": {"intercept": 0.80},
        "high_signal": {"intercept": 1.10},
    },
}

counter = 0
for model, regimes in cases.items():
    for regime, pars in regimes.items():
        if model == "linear":
            clean = pars["intercept"] + pars["slope"] * time
        elif model == "no_binding":
            clean = np.full_like(time, pars["intercept"], dtype=float)
        else:
            clean = seq_signal(time, S_mM, pars["rates"], pars["responses"])

        for noise_name, sigma in NOISE.items():
            counter += 1
            case_id = f"MS{counter:03d}"
            name = f"{case_id}_{model}_{regime}_{noise_name}.csv"
            cols = [time]
            headers = ["Time_min"]
            seeds = []

            for rep in range(1, 6):
                seed = BASE_SEED + counter * 1000 + rep
                seeds.append(seed)
                rng = np.random.default_rng(seed)
                cols.append(clean + rng.normal(0.0, sigma, clean.size))
                headers.append(f"rep{rep}")
                trace_template.append({
                    "case_id": case_id, "suite": "model_selection",
                    "file": f"model_selection/{name}", "trace_column": f"rep{rep}",
                    "replicate": rep, "truth_model": model, "truth_regime": regime,
                    "noise_level": noise_name, "noise_sigma_response_units": sigma,
                    "S_uM": S_uM, "E0_uM": 5.0, "ANCHOR_mode": "general_auto",
                    "ANCHOR_selected_model": "", "ANCHOR_selected_intermediates": "",
                    "ANCHOR_BIC": "", "DYNAFIT_selected_model": "",
                    "DYNAFIT_BIC": "", "parameter_recovery_notes": "",
                })

            with open(OUT / "model_selection" / name, "w", newline="") as f:
                w = csv.writer(f)
                w.writerow(headers)
                w.writerows(np.column_stack(cols))

            manifest.append({
                "case_id": case_id, "suite": "model_selection",
                "file": f"model_selection/{name}", "truth_model": model,
                "truth_regime": regime, "noise_level": noise_name,
                "noise_sigma_response_units": sigma, "n_replicates": 5,
                "time_unit": "min", "time_start": 0.0, "time_end": 2.0,
                "n_timepoints": len(time), "E0_uM": 5.0, "S_uM": S_uM,
                "ANCHOR_mode": "general_auto", "parameters_json": json.dumps(pars),
                "replicate_seeds": ";".join(map(str, seeds)),
            })

# -------------------- reversible-MM suite --------------------
time = np.round(np.linspace(0.0, 1.0, 201), 6)
substrates = [360, 675, 1350, 2250, 3150, 4500]
regimes = {
    "low_Km": {"kon": 10.0, "koff": 2.0, "kcat": 3.0},
    "mid_Km": {"kon": 4.0, "koff": 8.0, "kcat": 2.0},
    "high_Km": {"kon": 2.0, "koff": 14.0, "kcat": 1.0},
}

counter = 0
for regime, pars in regimes.items():
    Km = (pars["koff"] + pars["kcat"]) / pars["kon"]
    Vmax = pars["kcat"] * 40.0
    for noise_name, sigma in NOISE.items():
        counter += 1
        case_id = f"MM{counter:03d}"
        name = f"{case_id}_reversible_mm_{regime}_{noise_name}.csv"
        cols = [time]
        headers = ["Time_min"]
        seeds = []
        idx = 0

        for S in substrates:
            clean = reversible_mm_signal(
                time, S / 1000.0, pars["kon"], pars["koff"], pars["kcat"]
            )
            for rep in range(1, 4):
                idx += 1
                seed = BASE_SEED + 100000 + counter * 1000 + idx
                seeds.append(seed)
                rng = np.random.default_rng(seed)
                col = f"S{S}uM_rep{rep}"
                cols.append(clean + rng.normal(0.0, sigma, clean.size))
                headers.append(col)
                trace_template.append({
                    "case_id": case_id, "suite": "turnover",
                    "file": f"turnover/{name}", "trace_column": col,
                    "replicate": rep, "truth_model": "reversible_mm",
                    "truth_regime": regime, "noise_level": noise_name,
                    "noise_sigma_response_units": sigma, "S_uM": S,
                    "E0_uM": 40.0, "ANCHOR_mode": "turnover_auto",
                    "ANCHOR_selected_model": "", "ANCHOR_selected_intermediates": "",
                    "ANCHOR_BIC": "", "DYNAFIT_selected_model": "",
                    "DYNAFIT_BIC": "", "parameter_recovery_notes": "",
                })

        with open(OUT / "turnover" / name, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(headers)
            w.writerows(np.column_stack(cols))

        manifest.append({
            "case_id": case_id, "suite": "turnover",
            "file": f"turnover/{name}", "truth_model": "reversible_mm",
            "truth_regime": regime, "noise_level": noise_name,
            "noise_sigma_response_units": sigma, "n_replicates": 18,
            "time_unit": "min", "time_start": 0.0, "time_end": 1.0,
            "n_timepoints": len(time), "E0_uM": 40.0,
            "S_uM": "360;675;1350;2250;3150;4500 (3 replicates each)",
            "ANCHOR_mode": "turnover_auto",
            "parameters_json": json.dumps({
                **pars, "Km_mM": Km, "Vmax_uM_per_min": Vmax,
                "response_E": 1.0, "response_ES": 0.2, "response_P": 8.0
            }),
            "replicate_seeds": ";".join(map(str, seeds)),
        })

with open(OUT / "simulation_manifest.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(manifest[0].keys()))
    w.writeheader()
    w.writerows(manifest)

with open(OUT / "comparison_results_template.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(trace_template[0].keys()))
    w.writeheader()
    w.writerows(trace_template)

print(f"Generated {len(manifest)} cases and {len(trace_template)} traces in {OUT.resolve()}")
