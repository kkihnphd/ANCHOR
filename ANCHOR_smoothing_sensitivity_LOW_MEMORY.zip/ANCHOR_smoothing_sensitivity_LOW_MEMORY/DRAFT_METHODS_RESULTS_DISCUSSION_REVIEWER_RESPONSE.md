# Draft manuscript and reviewer-response language

## Methods template

### Sensitivity to Savitzky–Golay smoothing

ANCHOR retains the original normalized measurements during nonlinear fitting.
Under the default configuration, the fitting objective contains residuals to
both the raw observations and an auxiliary Savitzky–Golay-smoothed trace,
whereas candidate RSS, AIC, and BIC are calculated from residuals to the raw
observations. To determine whether smoothing materially affects candidate-model
selection, we performed a prespecified sensitivity analysis using the balanced
synthetic ground-truth panel.

The default Savitzky–Golay settings (window fraction 0.10, polynomial order 3)
were compared with a narrower 0.05 window, a broader 0.20 window, polynomial
orders 2 and 4 at the default 0.10 window, and a condition in which the
smoothed-target residual was removed from the nonlinear fitting objective.
All other ANCHOR settings were held fixed. The latter condition retained the
smoothed trace for robust noise estimation and auxiliary guardrails so that the
effect of the smoothed fitting target could be isolated without simultaneously
changing the definition of the no-binding noise estimate.

Robustness was quantified as the percentage of traces retaining the same
selected model and, for kinetic traces, the same selected phase count relative
to the default smoothing configuration. Results were also stratified by
low, medium, and high noise. Changes in raw-data RSS and BIC were recorded as
secondary endpoints.

## Results template

Across the balanced panel, [XX/XX] trace-setting comparisons retained the same
model assignment as the default smoothing configuration ([XX]%). Among kinetic
traces, [XX/XX] comparisons retained the same selected phase count. Model
selection remained [stable / most sensitive] at high noise, where [INSERT
HIGH-NOISE RESULT].

Changing the Savitzky–Golay window from 10% to either 5% or 20% resulted in
[INSERT] model-selection changes. Changing the polynomial order from 3 to 2 or
4 resulted in [INSERT] changes. Removing the smoothed-target term from the
nonlinear fitting residual resulted in [INSERT] changes. The maximum observed
change in selected-fit BIC was [INSERT], while the known-truth recovery rate
changed from [INSERT] under the default to [INSERT RANGE] across smoothing
conditions.

These results indicate that [INSERT CONCLUSION: e.g., final candidate selection
was insensitive to reasonable smoothing choices / changes were restricted to
specific high-noise borderline traces].

## Discussion template

Savitzky–Golay smoothing in ANCHOR is used as an auxiliary representation of
trace shape rather than as a replacement for the measured data. The final
information criteria are evaluated against the raw observations, which limits
the ability of smoothing alone to create an artificially favorable BIC.
Nevertheless, smoothing can influence optimization, robust noise estimation,
and therefore model selection indirectly. The dedicated sensitivity analysis
showed that [INSERT MAIN RESULT].

Any traces that change assignment under different smoothing conditions should
be interpreted as occurring near a model-identifiability or signal-to-noise
boundary rather than as providing strong evidence for a unique number of
kinetic phases. This is consistent with the broader synthetic benchmark, in
which recoverability depended on noise, timescale separation, and the finite
observation window.

## Reviewer response template

**Reviewer comment:** “A comment on how the Savitzky–Golay degree of smoothing
of noisy data impacts/affects the final selection model is in order.”

**Response:** We thank the reviewer for this suggestion. We have added a
dedicated Savitzky–Golay sensitivity analysis using the synthetic
ground-truth benchmark. We first clarify in the revised Methods that ANCHOR
does not replace the measured data with a smoothed trace. The default fitting
objective contains both raw-data residuals and an auxiliary residual to a
Savitzky–Golay-smoothed copy of the trace, whereas the RSS used to calculate
AIC and BIC is evaluated against the original raw observations.

We reanalyzed a balanced panel spanning direct, one-intermediate,
two-intermediate, linear, and no-binding traces at low, medium, and high noise.
The default smoothing configuration (10% window, third-order polynomial) was
compared with 5% and 20% windows, second- and fourth-order polynomials, and a
condition in which the smoothed-target residual was removed from the fitting
objective while the same smoothed trace was retained for the noise-estimation
guardrail.

[INSERT NUMERICAL RESULTS.]

These results have been added to the revised Methods, Results, and
Supplementary Figure/Table X. We now explicitly state that model assignments
that are unstable to reasonable smoothing choices should be treated as
borderline and should not be interpreted as evidence for a uniquely resolved
biochemical intermediate.
