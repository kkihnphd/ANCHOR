# Savitzky–Golay smoothing sensitivity analysis

## Reviewer question

The reviewer asked for a comment on how the degree of Savitzky–Golay smoothing
of noisy data affects the final selected model.

## Important detail about ANCHOR

ANCHOR does not replace the raw observations with the smoothed trace. Under the
default configuration, the nonlinear objective contains both:
- residuals to the raw normalized data; and
- an auxiliary residual to a Savitzky–Golay-smoothed copy of the trace.

The final candidate RSS, AIC, and BIC are calculated from the residuals to the
raw observations. The smoothed trace is also used by some auxiliary operations,
including robust noise estimation and initialization/shape guardrails.

For that reason, the primary analysis distinguishes between:
1. changing the *degree* of Savitzky–Golay smoothing; and
2. removing the smoothed-target term from the nonlinear fitting objective.

The `smoothed_target_off` setting does not erase all internal use of the
smoothed trace; it specifically removes the smoothed trace from the fitting
residual while retaining it for the noise/guardrail calculations. This avoids
changing the definition of the no-binding noise estimator at the same time.

## Primary settings

- Default: 10% smoothing window, polynomial order 3
- Smoothed-target residual OFF
- 5% window, polynomial order 3
- 20% window, polynomial order 3
- 10% window, polynomial order 2
- 10% window, polynomial order 4

An optional extended profile also tests smoothed-target weights of 0.75 and 3.0
versus the default 1.5.

## Prespecified balanced panel

The recommended analysis uses 30 traces:

5 truth classes:
- direct
- one intermediate
- two intermediates
- linear
- no binding

x 3 noise levels:
- low
- medium
- high

x 2 independently noise-seeded replicates.

The middle kinetic/signal regime is used for each truth class, matching the
balanced parameter-sensitivity analysis.

## Primary endpoints

- percentage of traces retaining the default selected model;
- percentage of kinetic traces retaining the default selected phase count;
- known-truth recovery rate;
- selection stability stratified by noise level and truth class;
- identities of any traces whose selected model changes.

## Secondary endpoints

- change in selected-fit BIC relative to the default;
- change in raw-data RSS relative to the default;
- raw-versus-smoothed RMSE, which quantifies how strongly each SG setting
  alters the normalized trace;
- effect on the robust noise estimate used by the no-binding guardrail.

## Optional high-noise confirmation

Because the reviewer specifically referred to noisy data, the runner includes a
high-noise panel containing the high-noise case for each of the five truth
classes. It can be run with all five replicates after the balanced analysis:

python run_anchor_smoothing_sensitivity.py --panel high_noise --profile primary --replicates 5 --out ANCHOR_smoothing_outputs_high_noise

This is recommended only if the balanced analysis shows borderline changes or
if an additional high-noise confirmation is desired.
