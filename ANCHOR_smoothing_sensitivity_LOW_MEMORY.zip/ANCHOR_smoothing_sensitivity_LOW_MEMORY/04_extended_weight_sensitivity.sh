#!/usr/bin/env bash
set -e
cd "/home/scs/kihn/ANCHOR/ANCHOR_smoothing_sensitivity_LOW_MEMORY"
python run_anchor_smoothing_sensitivity.py --panel balanced --profile extended --replicates 2
