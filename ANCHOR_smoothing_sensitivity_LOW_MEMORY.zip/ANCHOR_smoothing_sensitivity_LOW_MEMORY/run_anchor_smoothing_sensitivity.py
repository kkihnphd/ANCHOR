#!/usr/bin/env python
"""
Savitzky-Golay smoothing sensitivity analysis for ANCHOR.

This runner is intentionally process-isolated and sequential to avoid the
memory-pressure problem encountered with the earlier sensitivity analysis.

Recommended reviewer analysis:
    python run_anchor_smoothing_sensitivity.py --panel balanced --profile primary --replicates 2

Optional high-noise confirmation:
    python run_anchor_smoothing_sensitivity.py --panel high_noise --profile primary --replicates 5 --out ANCHOR_smoothing_outputs_high_noise

Quick stability check:
    python run_anchor_smoothing_sensitivity.py --panel quick --profile primary --replicates 1
"""

from __future__ import annotations

# Limit scientific-library thread pools BEFORE importing NumPy/SciPy/pandas.
import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")
os.environ.setdefault("MPLBACKEND", "Agg")

import argparse
import importlib.util
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import pandas as pd

SCRIPT_DIR = Path(__file__).resolve().parent
REQUESTED_ROOT = Path(r"/home/scs/kihn/ANCHOR/ANCHOR_smoothing_sensitivity_LOW_MEMORY")
HERE = REQUESTED_ROOT if REQUESTED_ROOT.exists() else SCRIPT_DIR

DEFAULT_ANCHOR = HERE / "ANCHOR.py"
DEFAULT_PACKAGE = HERE / "ANCHOR_reviewer_simulated_validation"
DEFAULT_OUT = HERE / "ANCHOR_smoothing_outputs_balanced"

BALANCED_CASES = [
    "MS004", "MS005", "MS006",  # direct, moderate, low/medium/high
    "MS013", "MS014", "MS015",  # one intermediate, moderate
    "MS022", "MS023", "MS024",  # two intermediates, moderate
    "MS031", "MS032", "MS033",  # linear, moderate
    "MS040", "MS041", "MS042",  # no binding, mid signal
]

QUICK_CASES = [
    "MS004", "MS013", "MS022", "MS031", "MS040"
]

HIGH_NOISE_CASES = [
    "MS006", "MS015", "MS024", "MS033", "MS042"
]

SETTINGS: Dict[str, Dict[str, Any]] = {
    "default_10pct_poly3": {
        "use_smoothed_target": True,
        "smooth_window_fraction": 0.10,
        "smooth_polyorder": 3,
        "smooth_weight": 1.5,
    },
    "smoothed_target_off": {
        "use_smoothed_target": False,
        "smooth_window_fraction": 0.10,
        "smooth_polyorder": 3,
        "smooth_weight": 1.5,
    },
    "window_5pct_poly3": {
        "use_smoothed_target": True,
        "smooth_window_fraction": 0.05,
        "smooth_polyorder": 3,
        "smooth_weight": 1.5,
    },
    "window_20pct_poly3": {
        "use_smoothed_target": True,
        "smooth_window_fraction": 0.20,
        "smooth_polyorder": 3,
        "smooth_weight": 1.5,
    },
    "poly2_10pct": {
        "use_smoothed_target": True,
        "smooth_window_fraction": 0.10,
        "smooth_polyorder": 2,
        "smooth_weight": 1.5,
    },
    "poly4_10pct": {
        "use_smoothed_target": True,
        "smooth_window_fraction": 0.10,
        "smooth_polyorder": 4,
        "smooth_weight": 1.5,
    },
    # Extended profile: objective-weight sensitivity, not strictly the degree
    # of Savitzky-Golay smoothing itself.
    "smooth_weight_0p75": {
        "use_smoothed_target": True,
        "smooth_window_fraction": 0.10,
        "smooth_polyorder": 3,
        "smooth_weight": 0.75,
    },
    "smooth_weight_3": {
        "use_smoothed_target": True,
        "smooth_window_fraction": 0.10,
        "smooth_polyorder": 3,
        "smooth_weight": 3.0,
    },
}

PRIMARY_SETTINGS = [
    "default_10pct_poly3",
    "smoothed_target_off",
    "window_5pct_poly3",
    "window_20pct_poly3",
    "poly2_10pct",
    "poly4_10pct",
]

EXTENDED_SETTINGS = list(SETTINGS.keys())


def load_anchor(anchor_path: Path):
    spec = importlib.util.spec_from_file_location("anchor_smoothing_worker", anchor_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load ANCHOR module: {anchor_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(spec.name, None)
        raise
    return module


def truth_label_from_anchor_row(row: pd.Series) -> str:
    model_type = str(row.get("model_type", ""))
    if model_type == "linear_only":
        return "linear"
    if model_type == "no_binding":
        return "no_binding"
    if model_type == "reversible_mm":
        return "reversible_mm"
    if model_type == "kinetic":
        try:
            n = int(float(row.get("best_n_intermediates", -99)))
        except Exception:
            return "kinetic_unknown"
        if n == 0:
            return "direct"
        if n == 1:
            return "one_intermediate"
        if n == 2:
            return "two_intermediate"
        return f"{n}_intermediates"
    return model_type or "unknown"


def phase_count(label: str):
    if label == "direct":
        return 0
    if label == "one_intermediate":
        return 1
    if label == "two_intermediate":
        return 2
    if label.endswith("_intermediates"):
        try:
            return int(label.split("_")[0])
        except Exception:
            return None
    return None


def make_replicate_subset(original_csv: Path, subset_csv: Path, n_replicates: int) -> None:
    df = pd.read_csv(original_csv)
    if df.shape[1] < n_replicates + 1:
        raise ValueError(
            f"{original_csv.name} contains only {df.shape[1]-1} traces; "
            f"cannot select {n_replicates}."
        )
    subset_csv.parent.mkdir(parents=True, exist_ok=True)
    df.iloc[:, : n_replicates + 1].to_csv(subset_csv, index=False)


def configure_case(
    mod,
    input_csv: Path,
    out_parent: Path,
    folder_name: str,
    n_replicates: int,
    overrides: Dict[str, Any],
):
    cfg = mod.FittingConfig()
    cfg.input_csv = str(input_csv)
    cfg.output_parent = str(out_parent)
    cfg.output_folder_name = folder_name

    cfg.input_time_unit = "minutes"
    cfg.enzyme_concentration_unit = "µM"
    cfg.substrate_concentration_unit = "µM"

    cfg.E0_uM = 5.0
    cfg.concentration_groups = [mod.ConcentrationGroup(200.0, n_replicates)]

    # Match the primary general automatic benchmark.
    cfg.analysis_mode = "general_auto"
    cfg.max_intermediates = 5
    cfg.include_zero_intermediate_kinetic_model = True
    cfg.use_standard_fit_mode = True
    cfg.use_slow_apo_fit_mode = True
    cfg.include_linear_only_model = True
    cfg.include_no_binding_model = True
    cfg.include_reversible_mm_model = False
    cfg.fit_michaelis_menten = False

    for key, value in overrides.items():
        if not hasattr(cfg, key):
            raise AttributeError(f"FittingConfig has no setting {key!r}")
        setattr(cfg, key, value)

    return cfg


def prune_heavy_outputs(case_dir: Path):
    # Keep audit tables/configuration; discard figures/workbooks to reduce disk
    # use and peak I/O during the sensitivity analysis.
    for p in case_dir.rglob("*"):
        if p.is_file() and p.suffix.lower() in {".png", ".tif", ".tiff", ".xlsx"}:
            try:
                p.unlink()
            except OSError:
                pass


def calculate_smoothing_diagnostics(mod, cfg, subset_csv: Path):
    """Describe how strongly this SG setting changes the normalized traces."""
    df = pd.read_csv(subset_csv)
    time = pd.to_numeric(df.iloc[:, 0], errors="raise").to_numpy(float)
    fitter = mod.StoppedFlowFitter(cfg)

    rows = []
    for trace_index, col in enumerate(df.columns[1:], start=1):
        raw = pd.to_numeric(df[col], errors="raise").to_numpy(float)
        norm = fitter.normalize_trace(raw, time)
        fit_mask = time >= float(cfg.fit_start_time)
        y = norm[fit_mask]
        ys = fitter.smooth_trace(y)

        diff = y - ys
        rows.append({
            "trace_index": trace_index,
            "trace_column": str(col),
            "raw_smoothed_RMSE": float(np.sqrt(np.mean(diff ** 2))),
            "raw_smoothed_MAD": float(np.median(np.abs(diff))),
            "raw_variance": float(np.var(y)),
            "smoothed_variance": float(np.var(ys)),
            "variance_ratio_smoothed_to_raw": (
                float(np.var(ys) / np.var(y)) if np.var(y) > 0 else np.nan
            ),
        })
    return pd.DataFrame(rows)


def worker_main(args) -> int:
    anchor_path = Path(args.anchor).resolve()
    package = Path(args.package).resolve()
    out_root = Path(args.out).resolve()

    manifest = pd.read_csv(package / "simulation_manifest.csv")
    row = manifest[
        (manifest["suite"].astype(str) == "model_selection")
        & (manifest["case_id"].astype(str) == args.worker_case)
    ]
    if row.empty:
        raise ValueError(f"Unknown model-selection case: {args.worker_case}")
    m = row.iloc[0]

    setting = args.worker_setting
    overrides = SETTINGS[setting]
    setting_out = out_root / setting
    setting_out.mkdir(parents=True, exist_ok=True)
    case_dir = setting_out / args.worker_case
    compact_path = case_dir / "smoothing_compact.csv"

    if compact_path.exists() and not args.force:
        return 0

    if args.force and case_dir.exists():
        shutil.rmtree(case_dir)

    subset_csv = (
        out_root
        / "_input_subsets"
        / f"{args.worker_case}_rep{args.replicates}.csv"
    )
    if not subset_csv.exists():
        make_replicate_subset(
            package / str(m["file"]),
            subset_csv,
            args.replicates,
        )

    mod = load_anchor(anchor_path)
    cfg = configure_case(
        mod,
        subset_csv,
        setting_out,
        args.worker_case,
        args.replicates,
        overrides,
    )

    diagnostics = calculate_smoothing_diagnostics(mod, cfg, subset_csv)

    mod.StoppedFlowFitter(cfg).run()

    best_path = case_dir / "best_fit_summary.csv"
    if not best_path.exists():
        raise FileNotFoundError(best_path)

    best = pd.read_csv(best_path)
    rows: List[Dict[str, Any]] = []

    for trace_index, (_, r) in enumerate(best.iterrows(), start=1):
        selected = truth_label_from_anchor_row(r)

        diag = diagnostics[
            diagnostics["trace_index"] == trace_index
        ].iloc[0]

        rec = {
            "setting": setting,
            "case_id": args.worker_case,
            "trace_index": trace_index,
            "truth_model": str(m["truth_model"]),
            "truth_regime": str(m["truth_regime"]),
            "noise_level": str(m["noise_level"]),
            "selected_model": selected,
            "selected_phase_count": phase_count(selected),
            "truth_phase_count": phase_count(str(m["truth_model"])),
            "correct_model": selected == str(m["truth_model"]),
            "use_smoothed_target": bool(cfg.use_smoothed_target),
            "smooth_window_fraction": float(cfg.smooth_window_fraction),
            "smooth_polyorder": int(cfg.smooth_polyorder),
            "smooth_weight": float(cfg.smooth_weight),
            "raw_smoothed_RMSE": diag["raw_smoothed_RMSE"],
            "raw_smoothed_MAD": diag["raw_smoothed_MAD"],
            "variance_ratio_smoothed_to_raw": diag[
                "variance_ratio_smoothed_to_raw"
            ],
        }

        for col in [
            "model_type",
            "fit_mode",
            "best_n_intermediates",
            "RSS",
            "AIC",
            "BIC",
            "n_params",
            "selection_reason",
            "no_binding_noise_sigma",
            "no_binding_signal_change_threshold",
            "best_nonconstant_signal_change",
        ]:
            if col in r.index:
                rec[col] = r[col]

        rows.append(rec)

    case_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(compact_path, index=False)

    if not args.keep_case_outputs:
        prune_heavy_outputs(case_dir)

    return 0


def aggregate(out_root: Path):
    compact_files = sorted(out_root.glob("*/*/smoothing_compact.csv"))
    if not compact_files:
        raise RuntimeError("No completed smoothing-sensitivity cases were found.")

    results = pd.concat(
        [pd.read_csv(p) for p in compact_files],
        ignore_index=True,
    )
    results.to_csv(
        out_root / "ANCHOR_smoothing_all_results.csv",
        index=False,
    )

    default = results[
        results["setting"] == "default_10pct_poly3"
    ][
        [
            "case_id",
            "trace_index",
            "selected_model",
            "selected_phase_count",
            "correct_model",
            "RSS",
            "BIC",
            "no_binding_noise_sigma",
            "raw_smoothed_RMSE",
        ]
    ].rename(
        columns={
            "selected_model": "default_selected_model",
            "selected_phase_count": "default_selected_phase_count",
            "correct_model": "default_correct_model",
            "RSS": "default_RSS",
            "BIC": "default_BIC",
            "no_binding_noise_sigma": "default_no_binding_noise_sigma",
            "raw_smoothed_RMSE": "default_raw_smoothed_RMSE",
        }
    )

    comp = results.merge(
        default,
        on=["case_id", "trace_index"],
        how="left",
    )

    comp["selection_unchanged_from_default"] = (
        comp["selected_model"].astype(str)
        == comp["default_selected_model"].astype(str)
    )

    kinetic_mask = comp["truth_model"].isin(
        ["direct", "one_intermediate", "two_intermediate"]
    )
    comp["phase_count_unchanged_from_default"] = False
    comp.loc[kinetic_mask, "phase_count_unchanged_from_default"] = (
        comp.loc[kinetic_mask, "selected_phase_count"].fillna(-99)
        == comp.loc[
            kinetic_mask, "default_selected_phase_count"
        ].fillna(-99)
    )

    comp["delta_BIC_vs_default"] = comp["BIC"] - comp["default_BIC"]
    comp["abs_delta_BIC_vs_default"] = comp[
        "delta_BIC_vs_default"
    ].abs()

    comp["RSS_pct_change_vs_default"] = (
        100.0 * (comp["RSS"] / comp["default_RSS"] - 1.0)
    )

    comp.to_csv(
        out_root / "ANCHOR_smoothing_trace_level_comparison.csv",
        index=False,
    )

    summary_rows = []
    for setting_name, group in comp.groupby("setting", sort=False):
        kinetic = group[
            group["truth_model"].isin(
                ["direct", "one_intermediate", "two_intermediate"]
            )
        ]

        summary_rows.append({
            "setting": setting_name,
            "n_traces": len(group),
            "selection_stability_vs_default": float(
                group["selection_unchanged_from_default"].mean()
            ),
            "truth_accuracy": float(group["correct_model"].mean()),
            "n_kinetic_traces": len(kinetic),
            "kinetic_phase_count_stability_vs_default": (
                float(
                    kinetic[
                        "phase_count_unchanged_from_default"
                    ].mean()
                )
                if len(kinetic)
                else np.nan
            ),
            "kinetic_truth_accuracy": (
                float(kinetic["correct_model"].mean())
                if len(kinetic)
                else np.nan
            ),
            "n_changed_selections": int(
                (~group["selection_unchanged_from_default"]).sum()
            ),
            "median_abs_delta_BIC": float(
                group["abs_delta_BIC_vs_default"].median()
            ),
            "max_abs_delta_BIC": float(
                group["abs_delta_BIC_vs_default"].max()
            ),
            "median_abs_RSS_change_pct": float(
                group["RSS_pct_change_vs_default"].abs().median()
            ),
            "max_abs_RSS_change_pct": float(
                group["RSS_pct_change_vs_default"].abs().max()
            ),
            "median_raw_smoothed_RMSE": float(
                group["raw_smoothed_RMSE"].median()
            ),
            "median_variance_ratio_smoothed_to_raw": float(
                group["variance_ratio_smoothed_to_raw"].median()
            ),
        })

    pd.DataFrame(summary_rows).to_csv(
        out_root / "ANCHOR_smoothing_summary.csv",
        index=False,
    )

    by_truth_noise = (
        comp.groupby(
            ["setting", "truth_model", "noise_level"],
            as_index=False,
        )
        .agg(
            n=("correct_model", "size"),
            truth_accuracy=("correct_model", "mean"),
            selection_stability_vs_default=(
                "selection_unchanged_from_default",
                "mean",
            ),
            median_abs_delta_BIC=(
                "abs_delta_BIC_vs_default",
                "median",
            ),
            median_raw_smoothed_RMSE=(
                "raw_smoothed_RMSE",
                "median",
            ),
        )
    )
    by_truth_noise.to_csv(
        out_root / "ANCHOR_smoothing_by_truth_and_noise.csv",
        index=False,
    )

    by_noise = (
        comp.groupby(["setting", "noise_level"], as_index=False)
        .agg(
            n=("correct_model", "size"),
            truth_accuracy=("correct_model", "mean"),
            selection_stability_vs_default=(
                "selection_unchanged_from_default",
                "mean",
            ),
            median_abs_delta_BIC=(
                "abs_delta_BIC_vs_default",
                "median",
            ),
            median_raw_smoothed_RMSE=(
                "raw_smoothed_RMSE",
                "median",
            ),
            median_noise_sigma=(
                "no_binding_noise_sigma",
                "median",
            ),
        )
    )
    by_noise.to_csv(
        out_root / "ANCHOR_smoothing_by_noise.csv",
        index=False,
    )

    changed = comp[
        (comp["setting"] != "default_10pct_poly3")
        & (~comp["selection_unchanged_from_default"])
    ].copy()
    changed.to_csv(
        out_root / "ANCHOR_smoothing_changed_traces.csv",
        index=False,
    )


def controller_main(args) -> int:
    package = Path(args.package).resolve()
    out_root = Path(args.out).resolve()
    out_root.mkdir(parents=True, exist_ok=True)

    manifest = pd.read_csv(package / "simulation_manifest.csv")
    manifest = manifest[
        manifest["suite"].astype(str) == "model_selection"
    ].copy()

    if args.panel == "quick":
        case_ids = QUICK_CASES
    elif args.panel == "balanced":
        case_ids = BALANCED_CASES
    elif args.panel == "high_noise":
        case_ids = HIGH_NOISE_CASES
    else:
        case_ids = manifest["case_id"].astype(str).tolist()

    if args.setting:
        requested = [
            s.strip()
            for s in args.setting.split(",")
            if s.strip()
        ]
        unknown = [s for s in requested if s not in SETTINGS]
        if unknown:
            raise ValueError(f"Unknown settings: {unknown}")
        settings = ["default_10pct_poly3"] + [
            s
            for s in requested
            if s != "default_10pct_poly3"
        ]
    elif args.profile == "primary":
        settings = PRIMARY_SETTINGS
    else:
        settings = EXTENDED_SETTINGS

    total_jobs = len(settings) * len(case_ids)

    print("ANCHOR Savitzky-Golay smoothing sensitivity analysis")
    print(f"Panel: {args.panel}")
    print(f"Replicates per condition: {args.replicates}")
    print(f"Settings: {len(settings)}")
    print(f"Case jobs: {total_jobs}")
    print("Jobs are strictly sequential and process-isolated.")
    print()

    failures = []
    job_no = 0

    for setting in settings:
        for case_id in case_ids:
            job_no += 1
            compact = (
                out_root
                / setting
                / case_id
                / "smoothing_compact.csv"
            )

            if compact.exists() and not args.force:
                print(
                    f"[{job_no}/{total_jobs}] reuse "
                    f"{setting}/{case_id}"
                )
                continue

            print(
                f"[{job_no}/{total_jobs}] run   "
                f"{setting}/{case_id}"
            )

            log_dir = out_root / "_logs" / setting
            log_dir.mkdir(parents=True, exist_ok=True)
            log_path = log_dir / f"{case_id}.log"

            cmd = [
                sys.executable,
                str(Path(__file__).resolve()),
                "--worker",
                "--worker-setting",
                setting,
                "--worker-case",
                case_id,
                "--replicates",
                str(args.replicates),
                "--anchor",
                str(Path(args.anchor).resolve()),
                "--package",
                str(package),
                "--out",
                str(out_root),
            ]

            if args.force:
                cmd.append("--force")
            if args.keep_case_outputs:
                cmd.append("--keep-case-outputs")

            env = os.environ.copy()
            env.update({
                "OMP_NUM_THREADS": "1",
                "OPENBLAS_NUM_THREADS": "1",
                "MKL_NUM_THREADS": "1",
                "NUMEXPR_NUM_THREADS": "1",
                "VECLIB_MAXIMUM_THREADS": "1",
                "MPLBACKEND": "Agg",
            })

            with open(log_path, "w", encoding="utf-8") as log:
                result = subprocess.run(
                    cmd,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    env=env,
                    cwd=HERE,
                )

            if result.returncode != 0:
                failures.append({
                    "setting": setting,
                    "case_id": case_id,
                    "returncode": result.returncode,
                    "log": str(log_path),
                })
                print(
                    f"    FAILED (return code "
                    f"{result.returncode}); see {log_path}"
                )
                if args.stop_on_failure:
                    break
            else:
                print("    completed; worker memory released")

        if failures and args.stop_on_failure:
            break

        try:
            aggregate(out_root)
        except Exception:
            pass

    if failures:
        pd.DataFrame(failures).to_csv(
            out_root / "ANCHOR_smoothing_failures.csv",
            index=False,
        )

    aggregate(out_root)

    print()
    print("Finished.")
    print("Primary outputs:")
    print(out_root / "ANCHOR_smoothing_summary.csv")
    print(out_root / "ANCHOR_smoothing_by_noise.csv")
    print(out_root / "ANCHOR_smoothing_by_truth_and_noise.csv")
    print(out_root / "ANCHOR_smoothing_changed_traces.csv")

    if failures:
        print(
            f"Failures: {len(failures)} "
            "(see ANCHOR_smoothing_failures.csv)"
        )

    return 0


def build_parser():
    p = argparse.ArgumentParser()
    p.add_argument("--anchor", default=str(DEFAULT_ANCHOR))
    p.add_argument("--package", default=str(DEFAULT_PACKAGE))
    p.add_argument("--out", default=str(DEFAULT_OUT))
    p.add_argument(
        "--panel",
        choices=["quick", "balanced", "high_noise", "full"],
        default="balanced",
    )
    p.add_argument(
        "--profile",
        choices=["primary", "extended"],
        default="primary",
    )
    p.add_argument(
        "--setting",
        default=None,
        help="Comma-separated explicit setting names.",
    )
    p.add_argument(
        "--replicates",
        type=int,
        choices=[1, 2, 3, 4, 5],
        default=2,
    )
    p.add_argument("--force", action="store_true")
    p.add_argument("--keep-case-outputs", action="store_true")
    p.add_argument("--stop-on-failure", action="store_true")

    # Internal worker mode.
    p.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    p.add_argument(
        "--worker-setting",
        default=None,
        help=argparse.SUPPRESS,
    )
    p.add_argument(
        "--worker-case",
        default=None,
        help=argparse.SUPPRESS,
    )
    return p


if __name__ == "__main__":
    args = build_parser().parse_args()

    if args.worker:
        raise SystemExit(worker_main(args))

    raise SystemExit(controller_main(args))
